This archive contains Pascal source for the Salsa20 stream cipher.

Salsa20 by D.J. Bernstein is an ECRYPT stream cipher submission that is
selected as a "Focus Phase 2 Cipher" (these are designs that eSTREAM
finds of particular interest).

The core of Salsa20 is a hash function with 64 bytes input and 64 bytes
output, the input blocks consist of 128 or 256 bits of key material, the
nonce or IV, and block numbers. The hashed output is used as a pseudo
random key stream or is xored with the plain text to produce the cipher
text.

The ECRYPT Salsa20 specification demands 20 rounds (or 10 double rounds)
for the hash function, but D.J. Bernstein himself has formally proposed
two variants with 8 and 12 rounds.

In the following table my implementations (program t_salwe, 1.8 GHz P4
with Win98) are compared with the reference C and ASM code from D.J.
Bernstein. The times in s for processing 576 MB (1 Mio 576 bytes blocks)
are measured: the columns kx show the values for key stream generation
with x rounds, and the ex columns have the corresponding encryption
times. The reference C code for the key stream generation is suboptimal
because it encrypts a zero stream.

  +-------------+------+-------+-------+-------+-------+-------+------+
  |    Compiler |   k8 |   k12 |   k20 |    e8 |   e12 |   e20 | Rem. |
  +-------------+------+-------+-------+-------+-------+-------+------+
  |  ASM P4 F12 |    - |     - |     - |  2.54 |  3.62 |  5.57 |  (1) |
  | GCC4.01 -O3 | 8.30 | 10.28 | 14.45 |  7.31 |  9.34 | 13.46 |  (2) |
  | VC6 SP4 /O2 | 6.48 |  8.19 | 11.53 |  6.32 |  7.91 | 11.26 |  (2) |
  +-------------+------+-------+-------+-------+-------+-------+------+
  |    Delphi 3 | 3.57 |  4.93 |  7.88 |  8.70 | 10.05 | 12.75 |    - |
  |    Delphi 6 | 3.58 |  4.94 |  7.88 |  8.83 | 10.18 | 12.88 |    - |
  | VPC 2.1.279 | 4.38 |  5.72 |  8.44 |  7.79 |  9.12 | 11.82 |    - |
  |   FPC 2.0.2 | 4.72 |  6.06 |  8.78 |  9.57 | 10.92 | 13.63 |    - |
  |    BP7 Real | 4.89 |  6.24 |  8.93 | 23.75 | 24.90 | 27.59 |  (3) |
  +-------------+------+-------+-------+-------+-------+-------+------+

(1) Calculated from D.J. Bernstein's cycles for 576 bytes
(2) Modified reference C code with static rounds variable
(3) ex bottleneck is the bytewise xor via three 16 bit pointers

My source implementation uses BASM for core hash function (TP5.X uses
Pascal with some inline).

Salsa20 is used as cryptographic random number generator in the salsar
unit.

